# app.py
from flask import Flask
from app1.database import db

def create_app():
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql+psycopg2://postgres:1234@localhost:5432/reciclappdb?client_encoding=utf8'
    db.init_app(app)
    return app