// Función para enviar el formulario de registro de actividad de reciclaje al servidor
function enviarRegistro() {
  // Aquí puedes agregar el código para enviar los datos del formulario al servidor
  // Por ejemplo, podrías enviar los datos utilizando una solicitud AJAX

  // Aquí simplemente mostramos un mensaje de confirmación
  alert("Registro de actividad enviado correctamente");
}

// Agregar evento de escucha al botón de registro
document.getElementById("btnRegistro").addEventListener("click", function() {
  enviarRegistro();
});


// Array con consejos ecológicos predefinidos
var consejosEco = [
  "Apaga las luces cuando salgas de una habitación para ahorrar energía.",
  "Reduce el consumo de plástico utilizando bolsas reutilizables cuando vayas de compras.",
  "Prefiere comprar productos locales y de temporada para reducir la huella de carbono de tu alimentación.",
  "Recicla los botes de cristal y crea lámparas o jarrones con ellos. Puedes pintarlos con Chalk Paint, envolverlos en cuerda para darle un toque más cálido o envolverlos con trozos de tela y puntilla"


  // Agrega más consejos aquí
];

// Función para obtener y mostrar un consejo ecológico aleatorio
function obtenerYMostrarConsejo() {
  // Obtener un índice aleatorio para seleccionar un consejo de la lista
  var indiceAleatorio = Math.floor(Math.random() * consejosEco.length);

  // Mostrar el consejo en un cuadro de diálogo
  alert("Consejo ecológico:\n\n" + consejosEco[indiceAleatorio]);
}

// Agregar evento de escucha al botón de obtener consejo
document.getElementById("btnObtenerConsejo").addEventListener("click", function() {
  obtenerYMostrarConsejo();
});


// Función para calcular la huella de carbono
function calcularHuellaCarbono() {
  // Recopilar datos del usuario
  var consumoEnergia = parseFloat(document.getElementById("consumoEnergia").value);
  var transporte = parseFloat(document.getElementById("transporte").value);
  var habitosAlimenticios = parseFloat(document.getElementById("habitosAlimenticios").value);
  // Agregar más variables según sea necesario

  // Calcular la huella de carbono (esto es solo un ejemplo, puedes usar fórmulas más precisas)
  var huellaCarbono = consumoEnergia + transporte + habitosAlimenticios;
  // Puedes agregar más factores y ajustar la fórmula según necesites

  // Mostrar la huella de carbono calculada
  alert("Tu huella de carbono es: " + huellaCarbono.toFixed(2) + " toneladas de CO2 por año");

  // Mostrar sugerencias para reducir la huella de carbono
  mostrarSugerenciasReduccion(huellaCarbono);
}

// Función para mostrar sugerencias para reducir la huella de carbono
function mostrarSugerenciasReduccion(huellaCarbono) {
  var sugerencias = 
  "Acortar el tiempo que se pasa bajo la ducha"
  "Bajar la calefacción 1 ºC (con esto ya se nota la diferencia)"
  "Cerrar el grifo mientras te lavas los dientes o lavas los platos"  
  ;

  // Agregar sugerencias basadas en la huella de carbono calculada
  if (huellaCarbono > 10) {
    sugerencias += "Considera reducir tu consumo de energía y utilizar fuentes renovables.\n";
  }
  if (huellaCarbono > 5) {
    sugerencias += "Prefiere medios de transporte más sostenibles como caminar, andar en bicicleta o utilizar el transporte público.\n";
  }
  // Agregar más sugerencias según sea necesario

  // Mostrar las sugerencias en un cuadro de diálogo
  alert("Sugerencias para reducir tu huella de carbono:\n\n" + sugerencias);
}

// Agregar evento de escucha al botón de calcular huella de carbono
document.getElementById("btnCalcularHuella").addEventListener("click", function() {
  calcularHuellaCarbono();
});

// Función para publicar un mensaje en la comunidad
function publicarMensaje() {
  var mensaje = document.getElementById("mensaje").value;
  // Aquí puedes agregar el código para enviar el mensaje al servidor o realizar otras acciones

  // Aquí simplemente mostramos un mensaje de confirmación
  alert("Mensaje publicado correctamente:\n\n" + mensaje);
}

// Agregar evento de escucha al botón de publicar mensaje
document.getElementById("btnPublicar").addEventListener("click", function() {
  publicarMensaje();
});

// Función para cargar y mostrar los proyectos de conservación
function cargarProyectos() {
  // Aquí puedes agregar el código para cargar los proyectos de conservación desde el servidor
  // Luego, puedes mostrar los proyectos en esta sección del HTML
}

// Llamar a la función para cargar proyectos cuando la página se carga completamente
window.onload = function() {
  cargarProyectos();
};

